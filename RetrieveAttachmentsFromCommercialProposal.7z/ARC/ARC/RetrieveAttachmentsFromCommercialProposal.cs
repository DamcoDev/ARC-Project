﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARC
{
    public class RetrieveAttachmentsFromCommercialProposal:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
        // Obtain the execution context from the service provider.
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

        // Get a reference to the organization service.
        IOrganizationServiceFactory factory =
            (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
        IOrganizationService service = factory.CreateOrganizationService(context.UserId);

        ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
        tracingService.Trace("Start");

        var entityId = context.PrimaryEntityId;
        Entity entity = (Entity)context.InputParameters["Target"];
            if (!entity.Contains("itspsa_opportunity"))
                return;
            tracingService.Trace("Start1");
            QueryExpression qryCommercialProposal = new QueryExpression("emitac_commercialproposal");
        qryCommercialProposal.Criteria.AddCondition("emitac_opportunityid", ConditionOperator.Equal, ((EntityReference)entity.Attributes["itspsa_opportunity"]).Id);
            qryCommercialProposal.ColumnSet = new ColumnSet(new string[] { "emitac_commercialproposalid" });
            EntityCollection ecCommercialProposal = service.RetrieveMultiple(qryCommercialProposal);
            if (ecCommercialProposal.Entities.Count > 0)
            {
                for (int i = 0; i < ecCommercialProposal.Entities.Count; i++)
                {
                    tracingService.Trace("Start2");
                    QueryExpression qryannotation = new QueryExpression("annotation");
                    qryannotation.Criteria.AddCondition("objectid", ConditionOperator.Equal,ecCommercialProposal.Entities[i].Id);
                    qryannotation.ColumnSet = new ColumnSet(true);
                    EntityCollection ecannotation = service.RetrieveMultiple(qryannotation);
                    if (ecannotation.Entities.Count > 0)
                    {
                        tracingService.Trace("Start3");
                        for (int j = 0; j < ecannotation.Entities.Count; j++) {
                            if (!ecannotation.Entities[j].Contains("documentbody"))
                                continue;
                            tracingService.Trace("Start3a");
                            //if (ecannotation.Entities[j].Attributes["documentbody"] == null)
                            //    continue;
                            Entity annotation = new Entity("annotation");
                            if (ecannotation.Entities[j].Contains("subject"))
                                annotation["subject"] = ecannotation.Entities[j].Attributes["subject"];
                            tracingService.Trace("Start4");
                            if (ecannotation.Entities[j].Contains("filename"))
                                annotation["filename"] = ecannotation.Entities[j].Attributes["filename"];
                            tracingService.Trace("Start5");
                            if (ecannotation.Entities[j].Contains("documentbody"))
                                annotation["documentbody"] = ecannotation.Entities[j].Attributes["documentbody"];
                            tracingService.Trace("Start6");
                            if (ecannotation.Entities[j].Contains("mimetype"))
                                annotation["mimetype"] = ecannotation.Entities[j].Attributes["mimetype"];

                            tracingService.Trace("Start7");
                           annotation["objectid"] = new EntityReference("itspsa_projecthandover", entityId);
                            tracingService.Trace("Start8");
                            service.Create(annotation);
                            tracingService.Trace("Start9");
                        }
                    }
                }
            }
               
    }
    }
}
